export default function(a, b, v) { // number1, number2, progress
  a = +a; b -= a; return a + b * v;
}