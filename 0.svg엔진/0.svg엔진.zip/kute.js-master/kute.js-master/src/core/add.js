import Tweens from '../objects/tweens.js'
export default (tw) => Tweens.push(tw)