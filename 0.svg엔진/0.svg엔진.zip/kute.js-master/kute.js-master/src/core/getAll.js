import Tweens from '../objects/tweens.js'
export default () => Tweens
