import trueProperty from './trueProperty.js'
export default trueProperty('transform')
