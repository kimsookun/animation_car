import transformProperty from './transformProperty.js'
export default transformProperty in document.head.style