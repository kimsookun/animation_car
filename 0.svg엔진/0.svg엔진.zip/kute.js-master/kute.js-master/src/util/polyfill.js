// IE10+
import 'minifill/src/Array.from.js'
import 'minifill/src/Array.prototype.includes.js'
import 'minifill/src/String.prototype.includes.js'