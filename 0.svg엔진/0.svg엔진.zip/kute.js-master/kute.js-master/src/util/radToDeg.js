export default (a) => {
  return a * 180 / Math.PI;
}