// used in preparePropertiesObject
export default {} 