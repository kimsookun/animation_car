// schedule property specific function on animation complete
export default {}