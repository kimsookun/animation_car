// util - a general object for utils like rgbToHex, processEasing
export default {}