// KUTE.js INTERPOLATE FUNCTIONS
// =============================
export default {}