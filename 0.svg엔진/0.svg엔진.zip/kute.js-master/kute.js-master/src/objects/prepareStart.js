// check current property value when .to() method is used
export default {}