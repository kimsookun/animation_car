let defaultOptions = {
  duration: 700,
  delay: 0,
  easing: 'linear'
}
export default defaultOptions