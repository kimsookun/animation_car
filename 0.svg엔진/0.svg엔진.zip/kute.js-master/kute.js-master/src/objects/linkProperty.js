// link properties to interpolate functions
export default {}