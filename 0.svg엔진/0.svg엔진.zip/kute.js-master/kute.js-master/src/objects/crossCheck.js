// checks for differences between the processed start and end values, 
// can be set to make sure start unit and end unit are same, 
// stack transforms, process SVG paths,
// any type of post processing the component needs
export default {}